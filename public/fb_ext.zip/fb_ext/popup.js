const tokenInput    = document.getElementById('token');
const intervalInput = document.getElementById('interval');
const fbNameInput   = document.getElementById('fbname');
const autoRelayChk  = document.getElementById('auto-relay');
const saveBtn       = document.getElementById('save');
const status        = document.getElementById('status');

// Load saved settings
chrome.storage.local.get(['jwt_token', 'auto_relay', 'poll_interval', 'fb_name', 'last_relayed', 'last_relayed_at'], (data) => {
  if (data.jwt_token)     tokenInput.value     = data.jwt_token;
  if (data.poll_interval) intervalInput.value  = data.poll_interval;
  if (data.fb_name)        fbNameInput.value    = data.fb_name;
  if (data.auto_relay !== undefined) autoRelayChk.checked = data.auto_relay;

  if (data.last_relayed) {
    document.getElementById('last-relayed-wrap').style.display = 'block';
    document.getElementById('last-text').textContent = data.last_relayed;
    document.getElementById('last-time').textContent = data.last_relayed_at || '';
  }
});

saveBtn.addEventListener('click', () => {
  const token    = tokenInput.value.trim();
  const interval = parseInt(intervalInput.value) || 30;
  const fbName   = fbNameInput.value.trim();
  const auto     = autoRelayChk.checked;

  if (!token) {
    status.textContent = 'Please enter a token.';
    status.className = 'status error';
    return;
  }

  chrome.storage.local.set({
    jwt_token: token,
    poll_interval: Math.max(10, Math.min(300, interval)),
    fb_name: fbName,
    auto_relay: auto
  }, () => {
    status.textContent = '✓ Saved! Refresh your Facebook tab.';
    status.className = 'status';
    setTimeout(() => status.textContent = '', 3000);
  });
});
