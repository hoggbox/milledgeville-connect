const API_URL = 'https://www.milledgevilleconnect.com/api/shoutouts';

// ── Spam blocklist — block ONLY these categories, let everything else through ─
const SPAM_PHRASES = [
  // Selling / marketplace
  'for sale','selling my','anyone want to buy','taking orders',
  'cash only','venmo','cashapp','price is firm',' obo','best offer',
  'asking price','make an offer','still available','still for sale',
  'brand new','gently used','dm me for price','message me for price',
  'firm on price','swap for','trade for','iso ','in search of','wtb','want to buy',
  'looking to buy','need to buy','serious inquiries only','serious buyers only',
  'pickup only','no trades','no lowballs','garage sale','yard sale','moving sale',

  // Jobs / hiring
  'now hiring','job opening','apply now','hiring immediately',
  'looking for employees','seeking employees','job posting',
  'we are hiring','help wanted','position available','full time position',
  'part time position','send resume','submit resume','now hiring for',

  // Food places / restaurants
  'now open','grand opening','our menu','specials today','daily special',
  'food truck','order online','catering available','now serving',
  'breakfast special','lunch special','dinner special','plate lunch',
  'taste of','farm to table',

  // Business ads / promos
  'towing has been proudly','request pittmans','pittman\'s towing',
  'baldwin bulletin','digital edition','advertis','sponsored',
  'available at stores','pick one up','subscribe','subscription',
  'debris removal service','pressure wash','lawn care','landscaping',
  'call us today','give us a call','our team is dedicated',
  'proudly serving','years of experience','free estimate',
  'discount','promo code','coupon','% off','special offer',
  'book your appointment','schedule your','call to book','we come to you',
  'mobile service','licensed and insured','book your spot','limited spots',
  'pm for details','inbox for price','text for info',

  // Pets — phrase-level (supplemented by smarter isPetPost)
  'lost dog','found dog','lost cat','found cat','lost pet','dogs','cats','found pet',
  'missing dog','missing cat','stray dog','stray cat','lab','pitbull',
  'anyone missing a','anyone lose a','anyone lost a',
  'puppies for','puppies available','kittens for','kittens available',
  'free to good home','rehoming','adopt a','up for adoption',
  'dog needs a home','cat needs a home',
];

// ── Smarter pet detection ──────────────────────────────────────────────────────
const PET_SUBJECTS = /\b(dog|dogs|cat|cats|puppy|puppies|kitten|kittens|pup|pups|doggo|pupper|kitty|kitties)\b/i;
const PET_CONTEXT  = /\b(lost|missing|escaped|got out|ran off|run off|stray|found|found a|anyone seen|anyone find|anyone have|seen my|seen a|spotted|looking for|searching for|reward|collar|tags|chipped|microchip|shelter|pound|animal control|spayed|neutered|fixed|friendly|please share|please help|help find|get home|came home|came back|still out|still missing|last seen|please return|belongs to|owner|pet|animal)\b/i;

function isPetPost(text) {
  return PET_SUBJECTS.test(text) && PET_CONTEXT.test(text);
}

// ── Traffic / community hazard signals ────────────────────────────────────────
const STRONG_TRAFFIC = /\b(accident|wreck|crash|blocking|blocked|slow down|back ?up|detour|road closed|closure|outage|power out|flooding|standing water|fire truck|on scene|hazard|debris|downed|down line|down tree)\b/i;
const WEAK_TRAFFIC   = /\b(traffic|road|highway|hwy|bypass|intersection|signal|light|sign)\b/i;

// ── ML-inspired Spam Scorer (weighted features + regex) ───────────────────────
// This is a lightweight, hand-crafted feature-based classifier (foundation of
// many production spam filters). Scores are tuned for local community groups.
// High score = likely spam / promo / sales. Traffic & urgent alerts get negative scores.
function calculateSpamScore(text) {
  if (!text) return 10;
  const lower = text.toLowerCase();
  let score = 0;

  // === Strong spam signals (weighted) ===
  const spamSignals = [
    // Sales / Marketplace
    { re: /\b(for sale|selling my|anyone want to buy|taking orders|cash only|venmo|cashapp|price is firm|\bobo\b|best offer|asking price|make an offer|still (available|for sale)|brand new|gently used|dm me for price|message me for price|firm on price|swap for|trade for)\b/i, w: 3.5 },
    { re: /\b(iso\b|in search of|wtb\b|want to buy|looking to (buy|purchase)|need to buy|serious (inquiries|buyers) only|pickup only|no (trades|lowballs)|garage sale|yard sale|moving sale)\b/i, w: 3.0 },

    // Jobs
    { re: /\b(now hiring|job opening|apply now|hiring immediately|looking for employees|seeking employees|job posting|we are hiring|help wanted|position available|(full|part) time position|send resume|submit resume)\b/i, w: 4.0 },

    // Food / Restaurants / Events with menu
    { re: /\b(now open|grand opening|our menu|specials today|daily special|food truck|order online|catering available|now serving|(breakfast|lunch|dinner) special|plate lunch)\b/i, w: 3.0 },

    // Business promos / services
    { re: /\b(towing has been proudly|request pittmans|pittman'?s towing|baldwin bulletin|digital edition|advertis|sponsored|available at stores|pick one up|subscribe|subscription|debris removal|pressure wash|lawn care|landscaping|call us today|give us a call|our team is dedicated|proudly serving|years of experience|free estimate|discount|promo code|coupon|% off|special offer|book your appointment|schedule your|call to book|we come to you|mobile service|licensed and insured|book your spot|limited spots)\b/i, w: 2.5 },
    { re: /\b(pm for (price|details)|inbox for (price|info)|text (me|us|for info)|call (me|us) (at|today))\b/i, w: 2.0 },

    // Generic CTA / promo language
    { re: /\b(limited time|while supplies last|first come first served|act now|don't miss out|special this week|this weekend only)\b/i, w: 1.8 },
  ];

  for (const sig of spamSignals) {
    if (sig.re.test(text)) score += sig.w;
  }

  // === Stylistic / behavioral spam indicators ===
  const urlCount = (text.match(/https?:\/\//g) || []).length;
  if (urlCount >= 1) score += 1.2 * urlCount;
  if (urlCount >= 2) score += 1.5; // multiple links often promo

  // Excessive caps / shouting
  if (/[A-Z]{6,}/.test(text) || (text.match(/[A-Z]/g) || []).length > text.length * 0.4) score += 1.0;

  // Emoji spam
  const emojiCount = (text.match(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu) || []).length;
  if (emojiCount >= 4) score += 1.2;
  if (emojiCount >= 8) score += 1.5;

  // Phone numbers outside of traffic context (common in sales)
  if (/\b(\d{3}[-.\s]?|\(\d{3}\)\s?)\d{3}[-.\s]?\d{4}\b/.test(text) && !STRONG_TRAFFIC.test(text)) {
    score += 2.0;
  }

  // Very long posts often copy-paste promos
  if (text.length > 650) score += 0.8;

  // === Ham / legitimate signals (reduce score) ===
  // Strong traffic / hazard / emergency always trusted
  if (STRONG_TRAFFIC.test(text)) score -= 12;

  // Other community / urgent signals
  if (/\b(wreck|accident|crash|blocked|road closed|power out|outage|fire|police|ems|sheriff|on scene|injured|hurt|help needed|please be careful|avoid the area)\b/i.test(text)) {
    score -= 5.5;
  }

  // Local event / info style (mild negative)
  if (/\b(tonight|today|this morning|this afternoon|tomorrow|update|just happened|happening now)\b/i.test(text) && text.length > 40) {
    score -= 1.5;
  }

  return Math.max(0, Math.round(score * 10) / 10); // keep 1 decimal
}

// ── Main isSpam (now uses smart scorer + legacy lists + priorities) ───────────
function isSpam(text) {
  if (!text || text.length < 10) return true;
  const lower = text.toLowerCase();

  // 1. Strong traffic / hazard / emergency → ALWAYS allow (highest priority)
  if (STRONG_TRAFFIC.test(text)) return false;

  // 2. Smart pet detection (lost/found etc.) → block from shoutouts (use Lost & Found feature instead)
  if (isPetPost(text)) return true;

  // 3. ML-inspired weighted score
  const score = calculateSpamScore(text);
  if (score >= 4.5) {
    console.log(`[MC Relay] 🚫 Spam blocked (score=${score}): ${text.substring(0, 70).replace(/\n/g, ' ')}...`);
    return true;
  }

  // 4. Legacy exact phrase blocklist (catches anything missed by regex)
  if (SPAM_PHRASES.some(p => lower.includes(p))) return true;

  // 5. Weak traffic/road reference without strong spam → let through
  if (WEAK_TRAFFIC.test(text)) return false;

  // 6. Bare URL only → spam
  if (/^https?:\/\/\S+$/.test(text.trim())) return true;

  return false;
}

// ── Parse a relative-time string into milliseconds ────────────────────────────
function parseRelativeTimeMs(str) {
  if (!str) return null;
  const s = str.toLowerCase().trim();
  if (/just now|moments? ago|now/.test(s)) return 0;

  const match = s.match(/^(\d+)\s*(m|min|mins|minute|minutes|h|hr|hrs|hour|hours|d|day|days)\b/i) ||
                s.match(/^(\d+)\s*(m|h|d|w)$/i);

  if (!match) return null;

  const val = parseInt(match[1], 10);
  const unit = match[2];

  if (/^(m|min|mins|minute|minutes)$/.test(unit)) return val * 60 * 1000;
  if (/^(h|hr|hrs|hour|hours)$/.test(unit)) return val * 60 * 60 * 1000;
  if (/^(d|day|days)$/.test(unit)) return val * 24 * 60 * 60 * 1000;

  return null;
}

// 1. SIMPLIFIED: getPostAgeMs only tries to find actual dates
function getPostAgeMs(card) {
  // Strategy 1: <abbr title="...">
  const abbr = card.querySelector('abbr[title]');
  if (abbr) {
    const parsed = Date.parse(abbr.getAttribute('title'));
    if (!isNaN(parsed)) return Date.now() - parsed;
  }

  // Strategy 2: Aria-labels
  const timeSelectors = ['a[aria-label]', 'span[aria-label]', '[role="link"][aria-label]'];
  for (const sel of timeSelectors) {
    const els = Array.from(card.querySelectorAll(sel));
    for (const el of els) {
      const label = el.getAttribute('aria-label') || '';
      if (/^comment by /i.test(label)) continue;
      if (/\b(ago|just now|minute|hour|day|week|month|min|hr)\b/i.test(label)) {
        const ms = parseRelativeTimeMs(label);
        if (ms !== null) return ms;
      }
    }
  }

  // Strategy 3: Aggressive CSS-aware visible text scan
  const headerEls = Array.from(card.querySelectorAll('a, span, div[dir="auto"]'));
  for (const el of headerEls) {
    const txt = (el.innerText || '').trim().toLowerCase();
    const cleanTxt = txt.replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/\s+/g, ' ');
    if (cleanTxt.length === 0 || cleanTxt.length > 15) continue;
    if (/^(just now|now|\d+\s*(m|min|mins|minute|minutes|h|hr|hrs|hour|hours|d|day|days)(\s*ago)?)$/i.test(cleanTxt)) {
      const ms = parseRelativeTimeMs(cleanTxt);
      if (ms !== null) return ms;
    }
  }

  // Strategy 4: HTML5 <time> tag fallback
  const timeEl = card.querySelector('time[datetime]');
  if (timeEl) {
    const parsed = Date.parse(timeEl.getAttribute('datetime'));
    if (!isNaN(parsed)) return Date.now() - parsed;
  }

  return null; // Just return null if nothing found
}

// ── Normalize text for stable dedup hashing + fuzzy matching ──────────────────
function normalizeText(text) {
  return text
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s]/g, ' ')     // turn punctuation into spaces for better word tokens
    .replace(/\s+/g, ' ')
    .trim();
}

// ── Jaccard word similarity for fuzzy duplicate detection ─────────────────────
function textSimilarity(a, b) {
  if (!a || !b) return 0;
  const wordsA = new Set(a.split(/\s+/).filter(w => w.length > 2));
  const wordsB = new Set(b.split(/\s+/).filter(w => w.length > 2));
  if (wordsA.size === 0 || wordsB.size === 0) return 0;

  let intersect = 0;
  for (const w of wordsA) {
    if (wordsB.has(w)) intersect++;
  }
  const union = wordsA.size + wordsB.size - intersect;
  return intersect / union;
}

// ── Stable post ID from normalized text ───────────────────────────────────────
function postId(text) {
  const norm = normalizeText(text);
  let h = 5381;
  for (let i = 0; i < norm.length; i++) {
    h = (Math.imul(h, 33) ^ norm.charCodeAt(i)) >>> 0;
  }
  return 'mc_' + h.toString(36);
}

// ── Dedup store: exact IDs (7 days) + recent norms for fuzzy (24h) ────────────
const SENT_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000; // 7 days for exact IDs
const RECENT_DEDUP_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24h for fuzzy norms
const MAX_RECENT_NORMS = 200;

function wasSent(id) {
  return new Promise(resolve => {
    chrome.storage.local.get('sent_ids', ({ sent_ids }) => {
      const map = (sent_ids && typeof sent_ids === 'object' && !Array.isArray(sent_ids))
        ? sent_ids : {};
      const entry = map[id];
      if (!entry) return resolve(false);
      resolve(Date.now() - entry < SENT_EXPIRY_MS);
    });
  });
}

function markSent(id, text = null) {
  chrome.storage.local.get('sent_ids', ({ sent_ids }) => {
    let map = (sent_ids && typeof sent_ids === 'object' && !Array.isArray(sent_ids))
      ? { ...sent_ids } : {};
    const now = Date.now();
    for (const k of Object.keys(map)) {
      if (now - map[k] > SENT_EXPIRY_MS) delete map[k];
    }
    map[id] = now;
    chrome.storage.local.set({ sent_ids: map });
  });

  // Also store normalized text for fuzzy duplicate detection
  if (text) {
    const norm = normalizeText(text);
    chrome.storage.local.get('sent_norms', ({ sent_norms }) => {
      let list = Array.isArray(sent_norms) ? [...sent_norms] : [];
      const now = Date.now();
      // Drop expired
      list = list.filter(e => now - e.ts < RECENT_DEDUP_EXPIRY_MS);
      // Avoid exact dups in the list
      if (!list.some(e => e.norm === norm)) {
        list.push({ norm, ts: now, id });
      }
      if (list.length > MAX_RECENT_NORMS) list = list.slice(-MAX_RECENT_NORMS);
      chrome.storage.local.set({ sent_norms: list });
    });
  }
}

async function isDuplicate(text) {
  const norm = normalizeText(text);
  const id = postId(text);

  // Exact match via ID
  if (await wasSent(id)) return true;

  // Fuzzy similarity against recently sent posts
  return new Promise(resolve => {
    chrome.storage.local.get('sent_norms', ({ sent_norms }) => {
      if (!sent_norms || !Array.isArray(sent_norms) || sent_norms.length === 0) {
        return resolve(false);
      }
      const now = Date.now();
      const fresh = sent_norms.filter(entry => now - entry.ts < RECENT_DEDUP_EXPIRY_MS);

      // Persist cleaned list if we removed old entries
      if (fresh.length !== sent_norms.length) {
        chrome.storage.local.set({ sent_norms: fresh });
      }

      for (const entry of fresh) {
        const sim = textSimilarity(norm, entry.norm);
        if (sim >= 0.82) { // 82%+ word overlap = near duplicate
          console.log(`[MC Relay] 🔁 Fuzzy duplicate (sim=${sim.toFixed(2)}) blocked: "${text.substring(0, 55).replace(/\n/g, ' ')}..."`);
          return resolve(true);
        }
      }
      resolve(false);
    });
  });
}

// ── Extract the post author's display name ────────────────────────────────────
function getPostAuthor(card) {
  const el = card.querySelector('[aria-label^="Actions for this post by "]');
  if (!el) return null;
  const label = el.getAttribute('aria-label') || '';
  const m = label.match(/^Actions for this post by (.+)$/);
  return m ? m[1].trim() : null;
}

// ── Settings ──────────────────────────────────────────────────────────────────
function getSettings() {
  return new Promise(resolve => {
    chrome.storage.local.get(['jwt_token', 'auto_relay', 'poll_interval', 'fb_name'], (data) => {
      resolve({
        token: data.jwt_token || null,
        autoRelay: data.auto_relay !== false,
        pollInterval: data.poll_interval || 30,
        fbName: (data.fb_name || '').trim().toLowerCase()
      });
    });
  });
}

// ── Image extraction ──────────────────────────────────────────────────────────
async function imageUrlToBase64(url) {
  try {
    const res = await fetch(url);
    const blob = await res.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch (e) {
    console.warn('[MC Relay] Image fetch failed:', e);
    return null;
  }
}

async function extractImages(card) {
  const imgs = Array.from(card.querySelectorAll('img'));
  const candidates = imgs.filter(img => {
    const src = img.src || '';
    if (!src.includes('fbcdn.net') && !src.includes('facebook.com')) return false;
    const w = img.naturalWidth || img.width;
    const h = img.naturalHeight || img.height;
    if (w > 0 && w < 100) return false;
    if (h > 0 && h < 100) return false;
    return true;
  });
  if (!candidates.length) return [];
  const b64 = await imageUrlToBase64(candidates[0].src);
  return b64 ? [b64] : [];
}

// ── Send to API ───────────────────────────────────────────────────────────────
async function sendAlert(text, images = [], buttonEl = null) {
  const { token } = await getSettings();
  if (!token) {
    showToast('⚠️ No token saved. Click the extension icon.', 'warn');
    return false;
  }

  if (buttonEl) {
    buttonEl.disabled = true;
    buttonEl.textContent = images.length ? 'Sending with photo…' : 'Sending…';
  }

  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text, images, location: null }),
    });

    if (res.ok) {
      if (buttonEl) {
        buttonEl.textContent = '✓ Sent!';
        buttonEl.classList.add('mc-sent');
      }
      showToast(`✓ Sent to Milledgeville Connect!${images.length ? ' (with photo)' : ''}`, 'success');
      updateLastRelayed(text);
      return true;
    } else {
      const body = await res.text();
      console.error('MC API error:', res.status, body);
      if (buttonEl) {
        buttonEl.textContent = '✗ Failed';
        buttonEl.classList.add('mc-error');
        setTimeout(() => {
          buttonEl.textContent = '🚦 Send to App';
          buttonEl.disabled = false;
          buttonEl.classList.remove('mc-error');
        }, 3000);
      }
      showToast(`✗ Error ${res.status} — check your token.`, 'error');
      return false;
    }
  } catch (err) {
    console.error('MC fetch error:', err);
    if (buttonEl) {
      buttonEl.textContent = '✗ Network error';
      setTimeout(() => {
        buttonEl.textContent = '🚦 Send to App';
        buttonEl.disabled = false;
      }, 3000);
    }
    showToast('✗ Network error — are you online?', 'error');
    return false;
  }
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function showToast(message, type = 'success') {
  const existing = document.getElementById('mc-toast');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.id = 'mc-toast';
  toast.className = `mc-toast mc-toast-${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add('mc-toast-visible'), 50);
  setTimeout(() => {
    toast.classList.remove('mc-toast-visible');
    setTimeout(() => toast.remove(), 400);
  }, 3500);
}

function updateLastRelayed(text) {
  chrome.storage.local.set({
    last_relayed: text.substring(0, 120),
    last_relayed_at: new Date().toLocaleTimeString()
  });
}

// ── On-page status badge ───────────────────────────────────────────────────────
function ensureStatusBadge() {
  let badge = document.getElementById('mc-status-badge');
  if (badge) return badge;
  badge = document.createElement('div');
  badge.id = 'mc-status-badge';
  badge.className = 'mc-status-badge';
  document.body.appendChild(badge);
  return badge;
}

function updateStatusBadge({ cardCount, sentThisScan }) {
  const badge = ensureStatusBadge();
  const time = new Date().toLocaleTimeString();

  chrome.storage.local.get('mc_total_sent', ({ mc_total_sent }) => {
    let total = mc_total_sent || 0;
    if (sentThisScan) {
      total += sentThisScan;
      chrome.storage.local.set({ mc_total_sent: total });
    }

    const cardLabel = cardCount === 0
      ? '⚠️ 0 cards found'
      : `${cardCount} card(s) checked`;

    badge.innerHTML =
      `<span class="mc-badge-dot"></span>` +
      `MC Relay &middot; ${cardLabel} &middot; last scan ${time} &middot; sent ${total}`;

    if (cardCount === 0) {
      badge.classList.add('mc-badge-warn');
    } else {
      badge.classList.remove('mc-badge-warn');
    }
  });
}

// ── Aggressive Highlights Detection ──────────────────────────────────────────
function isHighlightsCard(card) {
  const ariaEls = card.querySelectorAll('[aria-label]');
  for (const el of ariaEls) {
    const label = el.getAttribute('aria-label') || '';
    if (/\b(highlights|top posts|suggested)\b/i.test(label)) return true;
  }
  const headings = card.querySelectorAll('h2, h3, h4, span[dir="auto"]');
  for (const el of headings) {
    const txt = (el.innerText || el.textContent || '').trim();
    if (/^(group\s+)?highlights$/i.test(txt)) return true;
  }
  const innerArticles = card.querySelectorAll('article');
  if (innerArticles.length >= 2) return true;
  return false;
}

// ── Get all visible feed post cards ──────────────────────────────────────────
function getFeedCards() {
  const all = Array.from(document.querySelectorAll('[data-virtualized="false"]'));
  return all.filter(card => {
    const textEl = card.querySelector(
      '[data-ad-comet-preview="message"], [data-ad-rendering-role="story_message"]'
    );
    if (!textEl || textEl.innerText.trim().length < 10) return false;

    if (card.closest('[aria-label="Featured"]')) return false;

    // 🛑 HARD STOP: Never allow Highlights through
    if (isHighlightsCard(card)) {
      console.log('[MC Relay] 🛑 Hard-skipped Highlights card');
      return false;
    }
    return true;
  });
}

// ── Inject manual Send button onto a card ────────────────────────────────────
function injectButton(card) {
  if (card.querySelector('.mc-relay-btn')) return;

  const textEl = card.querySelector(
    '[data-ad-comet-preview="message"], [data-ad-rendering-role="story_message"]'
  );
  if (!textEl) return;
  const text = textEl.innerText.trim();
  if (text.length < 10) return;

  const btn = document.createElement('button');
  btn.className = 'mc-relay-btn';
  btn.textContent = '🚦 Send to App';
  btn.title = 'Send this alert to Milledgeville Connect';

  btn.addEventListener('click', async (e) => {
    e.stopPropagation();
    e.preventDefault();
    const images = await extractImages(card);
    const id = postId(text);
    const ok = await sendAlert(text, images, btn);
    if (ok) markSent(id, text);
  });

  const wrap = document.createElement('div');
  wrap.className = 'mc-btn-container';
  wrap.appendChild(btn);
  textEl.parentNode.insertBefore(wrap, textEl.nextSibling);
}

// ── In-memory send lock: prevents race conditions between poll ticks ──────────
const _sendingNow = new Set();

// ── Auto-relay: STRICT top 3 checking, 1-hour enforcement, smart spam + fuzzy dup ─
async function autoRelayScan() {
  const { autoRelay, fbName } = await getSettings();
  if (!autoRelay) {
    console.log('%c[MC Relay] Auto-relay is OFF — skipping scan', 'color:#888');
    const badge = ensureStatusBadge();
    badge.innerHTML = '<span class="mc-badge-dot"></span>MC Relay &middot; auto-relay OFF';
    badge.classList.add('mc-badge-warn');
    return;
  }

  window.scrollTo({ top: 0, behavior: 'instant' });
  await new Promise(r => setTimeout(r, 1200));

  // 🛑 Strict 1-Hour Window
  const ONE_HOUR_MS = 60 * 60 * 1000;

  // 🛑 Fetch only top 3 real posts
  const cards = getFeedCards().slice(0, 3);
  const ts = new Date().toLocaleTimeString();
  let sentThisScan = 0;

  console.groupCollapsed(`%c[MC Relay] Scan @ ${ts} — ${cards.length} card(s) checked`, 'color:#5af;font-weight:bold');

  for (let i = 0; i < cards.length; i++) {
    const card = cards[i];
    const textEl = card.querySelector(
      '[data-ad-comet-preview="message"], [data-ad-rendering-role="story_message"]'
    );
    if (!textEl) {
      console.log(`  [${i+1}] No text element — skipping`);
      continue;
    }

    const text = textEl.innerText.trim();
    const id = postId(text);
    const preview = text.substring(0, 60).replace(/\n/g, ' ');

    console.groupCollapsed(`  [${i+1}] "${preview}..."`);
    console.log('  ID:', id);

    if (_sendingNow.has(id)) {
      console.log('  SKIP — currently sending (race guard)');
      console.groupEnd(); continue;
    }

    const isDup = await isDuplicate(text);
    if (isDup) {
      console.log('  SKIP — duplicate or near-duplicate');
      console.groupEnd(); continue;
    }

    if (fbName) {
      const author = getPostAuthor(card);
      if (author && author.trim().toLowerCase() === fbName) {
        console.log(`  SKIP — your own post (${author})`);
        console.groupEnd(); continue;
      }
    }

    if (isSpam(text)) {
      console.log('  SKIP — matches blocked category / spam score');
      console.groupEnd(); continue;
    }

    const ageMs = getPostAgeMs(card);

    // 🛑 If age is unknown, assume it's new (0ms) so it doesn't get dropped
    let effectiveAgeMs = ageMs;
    if (effectiveAgeMs === null) {
      console.log('  ⚠️ Age unknown. Treating as brand new (0ms).');
      effectiveAgeMs = 0;
    }

    // 🛑 Strictly enforce the 1-hour limit
    if (effectiveAgeMs > ONE_HOUR_MS) {
      console.log('  SKIP — 🛑 Older than 1 hour');
      console.groupEnd(); continue;
    }

    const ageLabel = effectiveAgeMs === 0
      ? 'brand new (just now)'
      : effectiveAgeMs < 60000
        ? Math.round(effectiveAgeMs / 1000) + 's old'
        : effectiveAgeMs < 3600000
          ? Math.round(effectiveAgeMs / 60000) + 'm old'
          : Math.round(effectiveAgeMs / 3600000) + 'h old';
    console.log('  Age:', ageLabel);

    console.log('  SENDING...');
    _sendingNow.add(id);
    try {
      const images = await extractImages(card);
      if (images.length) console.log('  Image attached');
      const ok = await sendAlert(text, images);
      if (ok) {
        markSent(id, text);
        sentThisScan++;
        console.log('  SENT and marked');
      } else {
        console.log('  Send failed — will retry next poll');
      }
    } finally {
      _sendingNow.delete(id);
    }

    console.groupEnd();
    await new Promise(r => setTimeout(r, 1500));
  }

  console.groupEnd();
  updateStatusBadge({ cardCount: cards.length, sentThisScan });
}

// ── Scan and inject buttons on all visible feed cards ────────────────────────
function scanForButtons() {
  getFeedCards().forEach(card => injectButton(card));
}

// ── Hide chat windows to prevent interruptions ───────────────────────────────
function disableChatWindows() {
  const style = document.createElement('style');
  style.innerHTML = `
    /* Hide the chat tabs wrapper */
    div[role="complementary"] {
      display: none !important;
    }
    /* Hide specific chat bubbles/windows */
    div[aria-label^="Chat with"] {
      display: none !important;
    }
  `;
  document.head.appendChild(style);
  console.log('[MC Relay] Chat windows hidden.');
}

// ── Safer, Non-Aggressive Hide ──────────────────────────────────────────────
function hideChat() {
  const chatSelectors = [
    'div[aria-label="Chats"]',           // The main chat list container
    'div[aria-label^="Chat with"]',      // Individual chat windows
    'div[data-testid="chat_tab"]',       // Legacy chat tab identifier
    'div[data-testid="messenger_chat"]'  // Messenger specific container
  ];

  chatSelectors.forEach(sel => {
    document.querySelectorAll(sel).forEach(el => {
      // Only hide if it's actually visible
      if (el.style.display !== 'none') {
        el.style.setProperty('display', 'none', 'important');
      }
    });
  });
}

// ── Run it instantly, and then every 2 seconds to "sweep" the page
hideChat();
setInterval(hideChat, 2000);

// ── MutationObserver watches for new cards AND chats ─────────────────────────
const observer = new MutationObserver(() => {
  scanForButtons();
  hideChat(); // Add this line
});
observer.observe(document.body, { childList: true, subtree: true });

// ── Polling loop ──────────────────────────────────────────────────────────────
async function startPolling() {
  const { pollInterval } = await getSettings();

  scanForButtons();

  // Wait for Facebook feed to fully render before the first alert scan
  await new Promise(r => setTimeout(r, 4000));
  await autoRelayScan();

  // Periodic scan + button injection on the poll interval
  setInterval(async () => {
    scanForButtons();
    await autoRelayScan();
  }, Math.max(pollInterval, 30) * 1000);

  // Reload every ~90-150 seconds (randomized) to pull a truly fresh feed
  const RELOAD_DELAY_MS = (90 + Math.random() * 60) * 1000; // 90–150s
  setTimeout(() => {
    console.log(`[MC Relay] Reloading for fresh posts... (after ${Math.round(RELOAD_DELAY_MS/1000)}s)`);
    location.reload();
  }, RELOAD_DELAY_MS);
}

// ── Init ──────────────────────────────────────────────────────────────────────
(function initBadge() {
  disableChatWindows(); // 🛑 Add this line to hide chats on startup
  const badge = ensureStatusBadge();
  badge.innerHTML = '<span class="mc-badge-dot"></span>MC Relay &middot; starting...';
})();
setTimeout(startPolling, 4000);